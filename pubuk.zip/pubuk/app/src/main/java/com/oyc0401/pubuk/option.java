package com.oyc0401.pubuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class option extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);
    }
}