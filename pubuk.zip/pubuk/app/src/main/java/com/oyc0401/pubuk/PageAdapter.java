package com.oyc0401.pubuk;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class PageAdapter extends FragmentPagerAdapter {

    private ArrayList<Fragment> mData;
    public PageAdapter(@NonNull FragmentManager fm){
        super(fm);

        mData = new ArrayList<Fragment>();
        mData.add(new lunch1());
        //mData.add(new lunch2());
        //mData.add(new lunch3());
    }

    @NonNull
    @Override
    public CharSequence getPageTitle(int position) {

        if(position==0) return "북마크";
        if(position==1) return "홈";
        if(position==2) return "내정보";
        return (position+1)+"번째";
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return mData.get(position);
    }


    
    @Override
    public int getCount(){
        return mData.size();
    }

}
