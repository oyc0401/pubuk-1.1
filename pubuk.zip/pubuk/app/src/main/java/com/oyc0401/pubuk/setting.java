package com.oyc0401.pubuk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;


public class setting extends AppCompatActivity {

    private String SharedPrefFile = "com.example.android.SharedPreferences";
    int grade;
    int clas, i, j,schoolcode;

    final String[] school_name = new String[]{"부천북고등학교", "도당고등학교", "원종고등학교"};
    final String[] grade_name = new String[]{"1학년", "2학년", "3학년"};
    final String[] clas1 = new String[]{"1반", "2반", "3반", "4반", "5반", "6반", "7반", "8반", "9반"};
    final String[] clas2 = new String[]{"1반", "2반", "3반", "4반", "5반", "6반", "7반", "8반", "9반", "10반"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        SharedPreferences mPreferences = getSharedPreferences(SharedPrefFile, 0);
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        schoolcode = mPreferences.getInt("school_code", 7530072);
        grade = mPreferences.getInt("grade", 1);
        clas = mPreferences.getInt("class", 1);

        Button setschool = findViewById(R.id.school);
        Button setgrade = findViewById(R.id.grade);
        Button setclas = findViewById(R.id.clas);
        //Button setscore = findViewById(R.id.score);
        Button ok = findViewById(R.id.ok);
        setgrade.setText(grade + "학년");
        setclas.setText(clas + "반");

        /*setschool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder gradedlg = new AlertDialog.Builder(setting.this);
                gradedlg.setTitle("학교");

                gradedlg.setItems(school_name, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (school_name[which]){
                            case "부천북고등학교":
                                schoolcode=7530072;
                                break;
                            case "도당고등학교":
                                schoolcode=7530471;
                                break;
                            case "원종고등학교":
                                schoolcode=7530107;
                                break;
                        }
                        setschool.setText(school_name[which]);
                        preferencesEditor.putInt("school_code", schoolcode);
                        preferencesEditor.apply();
                    }
                });
                gradedlg.show();
            }
        });*/


        setgrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder gradedlg = new AlertDialog.Builder(setting.this);
                gradedlg.setTitle("학년");

                gradedlg.setItems(grade_name, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        grade = which + 1;
                        setgrade.setText(grade + "학년");
                        preferencesEditor.putInt("grade", grade);
                        preferencesEditor.apply();
                    }
                });
                gradedlg.show();
            }
        });

        setclas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder clasdlg = new AlertDialog.Builder(setting.this);
                clasdlg.setTitle("반");
                if (grade <= 2) {
                    clasdlg.setItems(clas1, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            clas = which + 1;
                            setclas.setText(clas + "반");
                        }
                    });
                } else {
                    clasdlg.setItems(clas2, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            clas = which + 1;
                            setclas.setText(clas + "반");
                            preferencesEditor.putInt("class", clas);
                            preferencesEditor.apply();
                        }
                    });
                }
                clasdlg.show();
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });
    }

    @Override
    public void onBackPressed() {
        SharedPreferences mPreferences = getSharedPreferences(SharedPrefFile, 0);
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        preferencesEditor.putInt("grade", grade);
        preferencesEditor.putInt("class", clas);
        preferencesEditor.putInt("setting_To_Main", 0);
        Log.d("로그","1로만ㅇ듦ㄴㅇㅇ");
        preferencesEditor.apply();

        finish();

    }
}