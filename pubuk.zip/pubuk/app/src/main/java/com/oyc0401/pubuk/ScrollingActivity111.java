package com.oyc0401.pubuk;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ScrollingActivity111 extends AppCompatActivity {

    int i = 1;
    int a = 0;
    int click1 = 0;
    final String[] ARR = new String[]{"서울대학교", "연세대학교", "고려대학교", "서울교육대학교", "한국교원대학교", "성균관대학교", "한양대학교", "서강대학교", "경인교육대학교", "이화여자대학교", "중앙대학교",
            "경희대학교", "서울시립대학교", "외국어대학교", "부산대학교", "경북대학교", "건국대학교", "동국대학교", "홍익대학교", "숙명여자대학교", "인하대학교", "아주대학교", "전남대학교", "국민대학교", "충남대학교", "숭실대학교",
            "세종대학교", "서울과학기술대학교", "단국대학교", "한양대학교(ERICA)", "명지대학교", "덕성여자대학교", "광운대학교", "상명대학교", "인천대학교", "전북대학교", "충북대학교", "가천대학교", "가톨릭대학교", "경기대학교", "서울여자대학교",
            "울산대학교", "한림대학교", "영남대학교", "경상대학교",
            "강원대학교", "부경대학교", "대구대학교", "인제대학교", "순천향대학교",};

    int size = 150;//확대사이즈
    int unicode1 = 169;//기본 대학코드
    int unicode2 = 30;//기본 전형
    String url1 = "http://www.adiga.kr/kcue/ast/eip/eis/inf/stdptselctn/eipStdGenSlcIemWebView.do?sch_year=2021&univ_cd=000";//어디가 url1
    String url2 = "&iem_cd=";//어디가 url2
    Dialog dilaog01; // 커스텀 다이얼로그
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrolling111);

        Toolbar toolbar = findViewById(R.id.toolbar);//툴바
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        WebView webView = findViewById(R.id.webview);
        webView.setWebChromeClient(new WebChromeClient());
        //webView.setWebViewClient(new WebViewClientClass());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setTextZoom(size);

        Button uni = findViewById(R.id.uni);
        Button hak1 = findViewById(R.id.hak1);
        Button hak2 = findViewById(R.id.hak2);
        Button hak3 = findViewById(R.id.hak3);
        Button plus = findViewById(R.id.plus);
        Button minus = findViewById(R.id.minus);

        dilaog01 = new Dialog(ScrollingActivity111.this);// Dialog 초기화
        dilaog01.requestWindowFeature(Window.FEATURE_NO_TITLE); // 타이틀 제거
        dilaog01.setContentView(R.layout.dialig1);
        ListView lv = dilaog01.findViewById(R.id.lv);
        adapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_tv, ARR);
        lv.setAdapter(adapter);

        //웹뷰 동작
        if (unicode1 < 10) {
            webView.loadUrl(url1 + "000" + unicode1 + url2 + unicode2);
        } else if (unicode1 < 100) {
            webView.loadUrl(url1 + "00" + unicode1 + url2 + unicode2);
        } else if (unicode1 < 1000) {
            webView.loadUrl(url1 + "0" + unicode1 + url2 + unicode2);
        } else {
            webView.loadUrl(url1 + unicode1 + url2 + unicode2);
        }

        //대학버튼 클릭
        uni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dilaog01.show();
            }
        });

        //리스트뷰 클릭
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            // 콜백매개변수는 순서대로 어댑터뷰, 해당 아이템의 뷰, 클릭한 순번, 항목의 아이디
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int which, long l) {
                a = which;
                if (click1 == 0) {
                    Toast.makeText(ScrollingActivity111.this, "이것은 대학순위가 아닙니다", Toast.LENGTH_SHORT).show();
                }
                click1 = 1;

                switch (ARR[which]) {
                    case "서울대학교":
                        unicode1 = 19;
                        break;
                    case "연세대학교":
                        unicode1 = 149;
                        break;
                    case "고려대학교":
                        unicode1 = 69;
                        break;
                    case "성균관대학교":
                        unicode1 = 133;
                        break;
                    case "한양대학교":
                        unicode1 = 203;
                        break;
                    case "서강대학교":
                        unicode1 = 120;
                        break;
                    case "중앙대학교":
                        unicode1 = 175;
                        break;
                    case "경희대학교":
                        unicode1 = 66;
                        break;
                    case "외국어대학교":
                        unicode1 = 192;
                        break;
                    case "서울시립대학교":
                        unicode1 = 40;
                        break;
                    case "건국대학교":
                        unicode1 = 52;
                        break;
                    case "동국대학교":
                        unicode1 = 100;
                        break;
                    case "홍익대학교":
                        unicode1 = 212;
                        break;
                    case "국민대학교":
                        unicode1 = 78;
                        break;
                    case "숭실대학교":
                        unicode1 = 143;
                        break;
                    case "세종대학교":
                        unicode1 = 138;
                        break;
                    case "단국대학교":
                        unicode1 = 82;
                        break;
                    case "인하대학교":
                        unicode1 = 169;
                        break;
                    case "아주대학교":
                        unicode1 = 146;
                        break;
                    case "인천대학교":
                        unicode1 = 2660;
                        break;
                    case "한양대학교(ERICA)":
                        unicode1 = 204;
                        break;
                    case "광운대학교":
                        unicode1 = 74;
                        break;
                    case "명지대학교":
                        unicode1 = 109;
                        break;
                    case "가톨릭대학교":
                        unicode1 = 46;
                        break;
                    case "이화여자대학교":
                        unicode1 = 163;
                        break;
                    case "부산대학교":
                        unicode1 = 14;
                        break;
                    case "울산대학교":
                        unicode1 = 158;
                        break;
                    case "한림대학교":
                        unicode1 = 198;
                        break;
                    case "경북대학교":
                        unicode1 = 5;
                        break;
                    case "전북대학교":
                        unicode1 = 25;
                        break;
                    case "전남대학교":
                        unicode1 = 23;
                        break;
                    case "충남대학교":
                        unicode1 = 29;
                        break;
                    case "영남대학교":
                        unicode1 = 151;
                        break;
                    case "경상대학교":
                        unicode1 = 7;
                        break;
                    case "강원대학교":
                        unicode1 = 3;
                        break;
                    case "부경대학교":
                        unicode1 = 13;
                        break;
                    case "대구대학교":
                        unicode1 = 84;
                        break;
                    case "인제대학교":
                        unicode1 = 164;
                        break;
                    case "순천향대학교":
                        unicode1 = 142;
                        break;
                    case "서울교육대학교":
                        unicode1 = 255;
                        break;
                    case "숙명여자대학교":
                        unicode1 = 141;
                        break;
                    case "서울과학기술대학교":
                        unicode1 = 36;
                        break;
                    case "상명대학교":
                        unicode1 = 117;
                        break;
                    case "덕성여자대학교":
                        unicode1 = 99;
                        break;
                    case "서울여자대학교":
                        unicode1 = 126;
                        break;
                    case "경인교육대학교":
                        unicode1 = 256;
                        break;
                    case "한국교원대학교":
                        unicode1 = 31;
                        break;
                    case "가천대학교":
                        unicode1 = 63;
                        break;
                    case "충북대학교":
                        unicode1 = 30;
                        break;
                    case "경기대학교":
                        unicode1 = 56;
                        break;
                    case "00대학교":
                        unicode1 = 00;
                        break;


                    default:
                        unicode1 = which;
                }

                if (unicode1 < 10) {
                    webView.loadUrl(url1 + "000" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 100) {
                    webView.loadUrl(url1 + "00" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 1000) {
                    webView.loadUrl(url1 + "0" + unicode1 + url2 + unicode2);
                } else {
                    webView.loadUrl(url1 + unicode1 + url2 + unicode2);
                }
                uni.setText(ARR[which]);
                dilaog01.cancel();
            }
        });

        //화면 축소
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 150;
                webView.getSettings().setTextZoom(size);
            }
        });

        //화면 확대
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 250;
                webView.getSettings().setTextZoom(size);
            }
        });

        //학종 버튼설정
        hak1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unicode2 = 30;
                if (unicode1 < 10) {
                    webView.loadUrl(url1 + "000" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 100) {
                    webView.loadUrl(url1 + "00" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 1000) {
                    webView.loadUrl(url1 + "0" + unicode1 + url2 + unicode2);
                } else {
                    webView.loadUrl(url1 + unicode1 + url2 + unicode2);
                }
            }
        });

        //교과 버튼설정
        hak2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unicode2 = 31;
                if (unicode1 < 10) {
                    webView.loadUrl(url1 + "000" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 100) {
                    webView.loadUrl(url1 + "00" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 1000) {
                    webView.loadUrl(url1 + "0" + unicode1 + url2 + unicode2);
                } else {
                    webView.loadUrl(url1 + unicode1 + url2 + unicode2);
                }
            }
        });

        //정시 버튼설정
        hak3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unicode2 = 32;
                if (unicode1 < 10) {
                    webView.loadUrl(url1 + "000" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 100) {
                    webView.loadUrl(url1 + "00" + unicode1 + url2 + unicode2);
                } else if (unicode1 < 1000) {
                    webView.loadUrl(url1 + "0" + unicode1 + url2 + unicode2);
                } else {
                    webView.loadUrl(url1 + unicode1 + url2 + unicode2);
                }
            }
        });

    }

    //메뉴만들기
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_scrolling_activity111, menu);
        return true;
    }

    //메뉴 클릭 설정
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = new Intent(Intent.ACTION_VIEW);

        switch (item.getItemId()) {
            //자세히보기 눌렀을시
            case R.id.unifull:
                if (unicode1 < 10) {
                    intent.setData(Uri.parse("http://adiga.kr/kcue/ast/eip/eis/inf/stdptselctn/eipStdGenSlcIemCmprGnrl2.do?p_menu_id=PG-EIP-16001&chkUnivList=000000" + unicode1 + "&sch_year=2021"));
                } else if (unicode1 < 100) {
                    intent.setData(Uri.parse("http://adiga.kr/kcue/ast/eip/eis/inf/stdptselctn/eipStdGenSlcIemCmprGnrl2.do?p_menu_id=PG-EIP-16001&chkUnivList=00000" + unicode1 + "&sch_year=2021"));
                } else if (unicode1 < 1000) {
                    intent.setData(Uri.parse("http://adiga.kr/kcue/ast/eip/eis/inf/stdptselctn/eipStdGenSlcIemCmprGnrl2.do?p_menu_id=PG-EIP-16001&chkUnivList=0000" + unicode1 + "&sch_year=2021"));
                } else {
                    intent.setData(Uri.parse("http://adiga.kr/kcue/ast/eip/eis/inf/stdptselctn/eipStdGenSlcIemCmprGnrl2.do?p_menu_id=PG-EIP-16001&chkUnivList=0000" + unicode1 + "&sch_year=2021"));
                }
                startActivity(intent);
                break;

            //입학처 눌렀을시
            /*case R.id.uniurl:              (공개해야되서 잠시 가려놓음)
                switch (ARR[a]) {
                    case "서울대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "연세대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "고려대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "성균관대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "한양대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "서강대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "중앙대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "경희대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "외국어대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "서울시립대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "건국대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "동국대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "홍익대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "국민대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "숭실대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "세종대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "단국대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "인하대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "아주대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "인천대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "한양대학교(ERICA)":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "광운대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "명지대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "가톨릭대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "이화여자대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "부산대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "울산대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "한림대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "경북대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "전북대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "전남대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "충남대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "영남대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "경상대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "강원대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "부경대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "대구대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "인제대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "순천향대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "서울교육대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "숙명여자대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "서울과학기술대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "상명대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "덕성여자대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "서울여자대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "경인교육대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "한국교원대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "가천대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "충북대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                    case "경기대학교":
                        intent.setData(Uri.parse("https://admission.snu.ac.kr/"));
                        startActivity(intent);
                        break;
                }
                break;*/

            //뒤로가기 눌렀을시
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    
    //웹뷰 설정 , 이게 왜 있을까?
    /*private class WebViewClientClass extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

            return true;
        }
    }*/

    //일시정지시
    @Override
    protected void onPause() {
        super.onPause();
        //overridePendingTransition(0, 0);
    }


}